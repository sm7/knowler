"""
Bookmark ingest adapter.

Parses browser-exported bookmark HTML files (Chrome, Safari, Firefox).
Creates source rows with source_type='bookmark' and ingest_state='needs_review'
unless trusted domain/folder rules auto-promote the bookmark.

Architecture: §45.2 — Bookmark ingest
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import urllib.parse
from datetime import datetime, timezone
from typing import Any

import structlog
from bs4 import BeautifulSoup
from ulid import ULID

log = structlog.get_logger(__name__)


def _extract_domain(url: str) -> str:
    try:
        return urllib.parse.urlparse(url).netloc.lower().removeprefix("www.")
    except Exception:
        return ""


def _timestamp_to_iso(ts_str: str) -> str | None:
    """Convert a bookmark ADD_DATE (Unix timestamp) to ISO 8601."""
    try:
        ts = int(ts_str)
        return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
    except (ValueError, TypeError):
        return None


def parse_bookmark_html(html_path: str | pathlib.Path) -> list[dict[str, Any]]:
    """
    Parse a browser-exported bookmarks HTML file.

    Returns a list of bookmark dicts with fields:
      title, url, folder_path, added_at, domain, raw_html_snippet
    """
    path = pathlib.Path(html_path)
    html = path.read_text(encoding="utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")
    bookmarks: list[dict[str, Any]] = []
    # Start from the first DL element to avoid html/body wrapping
    root = soup.find("dl") or soup
    _walk_folder(root, [], bookmarks)
    log.info("parsed_bookmarks", count=len(bookmarks), source=str(path))
    return bookmarks


def _walk_folder(
    node: Any,
    folder_stack: list[str],
    results: list[dict[str, Any]],
) -> None:
    """Recursively walk DL/DT structure of Netscape bookmark format.

    html.parser does not auto-close <dt> tags, so sibling DTs end up incorrectly
    nested inside each other.  We handle this in two ways:
    - After processing a bookmark DT, recurse into the DT itself so any DTs that
      html.parser nested inside it are also visited.
    - After processing a folder DT (h3 + inner DL), walk the DT's remaining children
      that appear *after* the inner DL (html.parser puts sibling DTs there too).
    """
    for child in node.children:
        if not hasattr(child, "name"):
            continue
        if child.name == "dt":
            h3 = child.find("h3", recursive=False)
            dl = child.find("dl", recursive=False)
            a = child.find("a", recursive=False)

            if h3 and dl:
                # Folder (html.parser style: inner DL is a direct child of DT)
                folder_name = h3.get_text(strip=True)
                _walk_folder(dl, folder_stack + [folder_name], results)
                # html.parser may nest sibling DTs inside this folder DT after the
                # inner DL (e.g. the next top-level folder ends up here).
                after_dl = False
                for sub in child.children:
                    if not hasattr(sub, "name"):
                        continue
                    if sub is dl:
                        after_dl = True
                        continue
                    if after_dl and sub.name in ("dt", "dl", "p"):
                        _walk_folder(sub, folder_stack, results)
            elif a and a.get("href"):
                # Bookmark
                url = a["href"].strip()
                title = a.get_text(strip=True) or url
                add_date = a.get("add_date") or a.get("added")
                results.append(
                    {
                        "title": title,
                        "url": url,
                        "folder_path": " / ".join(folder_stack) if folder_stack else "",
                        "added_at": _timestamp_to_iso(add_date) if add_date else None,
                        "domain": _extract_domain(url),
                    }
                )
                # html.parser nests the *next* sibling DT inside this bookmark DT;
                # recurse into it to pick those up.
                _walk_folder(child, folder_stack, results)
        elif child.name in ("dl", "p", "body", "html"):
            # Recurse into containers; <p> is a separator in Netscape bookmark format
            _walk_folder(child, folder_stack, results)


def should_auto_promote(
    bookmark: dict[str, Any],
    trusted_domains: list[str],
    trusted_folders: list[str],
) -> bool:
    """
    Return True if this bookmark should be auto-promoted to 'approved'.

    Rules (OR logic):
    1. domain is in trusted_domains list
    2. any part of folder_path matches a trusted_folder pattern
    """
    domain = bookmark.get("domain", "")
    folder = bookmark.get("folder_path", "").lower()

    if domain and any(domain.endswith(td.lower()) for td in trusted_domains):
        return True

    for tf in trusted_folders:
        if tf.lower() in folder:
            return True

    return False


def build_source_rows(
    bookmarks: list[dict[str, Any]],
    project_id: str,
    trusted_domains: list[str],
    trusted_folders: list[str],
    raw_dir: pathlib.Path,
) -> list[dict[str, Any]]:
    """
    Convert parsed bookmarks into source rows ready for DB insertion.

    Deduplicates by URL within this batch.
    """
    seen_urls: set[str] = set()
    rows: list[dict[str, Any]] = []

    for bm in bookmarks:
        url = bm.get("url", "").strip()
        if not url or url in seen_urls or url.startswith("javascript:"):
            continue
        seen_urls.add(url)

        source_id = f"src_{ULID()}"
        domain = bm.get("domain", _extract_domain(url))

        auto_promote = should_auto_promote(bm, trusted_domains, trusted_folders)
        ingest_state = "approved" if auto_promote else "needs_review"

        # Write a tiny stub file to raw/bookmark_candidates/
        stub_path = raw_dir / "bookmark_candidates" / f"{source_id}.json"
        stub_path.parent.mkdir(parents=True, exist_ok=True)
        stub_data = json.dumps(bm, ensure_ascii=False, indent=2)
        stub_path.write_text(stub_data, encoding="utf-8")

        checksum = hashlib.sha256(url.encode()).hexdigest()

        rows.append(
            {
                "id": source_id,
                "project_id": project_id,
                "source_type": "bookmark",
                "origin_type": "bookmark_import",
                "title": bm.get("title", url)[:1000],
                "canonical_url": url,
                "display_url": url[:500],
                "domain": domain[:255],
                "raw_path": str(stub_path),
                "mime_type": "application/x-bookmark",
                "checksum_sha256": checksum,
                "byte_size": len(stub_data.encode()),
                "trust_level": "medium" if auto_promote else "unknown",
                "status": "pending",
                "ingest_state": ingest_state,
                "source_date": bm.get("added_at"),
                "metadata_json": json.dumps(
                    {
                        "folder_path": bm.get("folder_path", ""),
                        "browser_source": "unknown",
                        "auto_promoted": auto_promote,
                    }
                ),
            }
        )

    return rows
