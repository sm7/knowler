"""
Knowledge compiler pipeline.

Generates and maintains wiki pages from normalized sources.

Compile flow:
1. For each normalized source that hasn't been compiled:
   a. Generate a source summary page (wiki/sources/<slug>.md)
2. For each significant entity with enough supporting sources:
   a. Generate or update a concept page (wiki/concepts/<slug>.md)
3. Update index pages
4. Update backlinks (relations table)

Architecture: §18, §42.4
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
from datetime import datetime, timezone
from typing import Any

import structlog
from jinja2 import Environment, FileSystemLoader
from ulid import ULID

from knowler_engine.jobs.types import JobContext
from knowler_engine.llm.provider import LLMError, LLMProvider
from knowler_engine.storage.atomic import ConflictError, snapshot, write_atomic

log = structlog.get_logger(__name__)

_PROMPTS_DIR = pathlib.Path(__file__).parent.parent.parent / "prompts"
_jinja = Environment(loader=FileSystemLoader(str(_PROMPTS_DIR)), autoescape=False)

# Minimum sources needed before creating a concept page
_MIN_SOURCES_FOR_CONCEPT = 1

# Max sources to include in concept page context
_MAX_SOURCES_PER_CONCEPT = 5


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _slugify(text: str) -> str:
    s = text.lower().strip()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_]+", "-", s)
    s = re.sub(r"-+", "-", s)
    return s.strip("-")[:80]


def _extract_frontmatter_and_body(markdown: str) -> tuple[str, str]:
    """Split --- frontmatter --- from body. Returns (frontmatter_block, body)."""
    if not markdown.startswith("---"):
        return "", markdown
    end = markdown.find("---", 3)
    if end < 0:
        return "", markdown
    return markdown[3:end].strip(), markdown[end + 3:].strip()


async def compile_source_summary(
    source_id: str,
    project_id: str,
    db: Any,
    vault: Any,
    llm: LLMProvider,
    tier: str = "balanced",
) -> str | None:
    """
    Compile a source summary wiki page.

    Returns the page_id, or None on failure.
    """
    source = await db.fetchone(
        "SELECT * FROM sources WHERE id=? AND project_id=?",
        (source_id, project_id),
    )
    if not source:
        return None

    source = dict(source)
    meta = json.loads(source.get("metadata_json") or "{}")
    summary = meta.get("summary", source.get("title", "No summary available"))

    # Get entities for this source
    entities_rows = await db.fetchall(
        """
        SELECT e.entity_type, e.display_name as name
        FROM entities e
        WHERE e.project_id=? AND e.created_from_source_id=?
        ORDER BY e.confidence DESC LIMIT 10
        """,
        (project_id, source_id),
    )
    entities = [dict(r) for r in entities_rows]

    # Get claims for this source
    claims_rows = await db.fetchall(
        """
        SELECT claim_text as text, claim_kind, confidence
        FROM claims WHERE project_id=? AND created_from_source_id=?
        ORDER BY confidence DESC LIMIT 8
        """,
        (project_id, source_id),
    )
    claims = [dict(r) for r in claims_rows]

    # Build page metadata
    title = source.get("title") or f"Source {source_id[:12]}"
    slug = _slugify(title)
    page_id = f"pg_{ULID()}"
    now = _now_iso()

    # Check if page already exists
    existing_page_row = await db.fetchone(
        "SELECT id, file_path, body_sha256 FROM pages WHERE project_id=? AND file_path LIKE '%sources%' AND slug=?",
        (project_id, slug),
    )

    wiki_path = vault.wiki_path("source_summary", slug)

    # Render prompt
    template = _jinja.get_template("compile_source_summary_v1.md")
    prompt = template.render(
        source_id=source_id,
        page_id=page_id,
        project_id=project_id,
        source_type=source.get("source_type", "unknown"),
        title=title,
        url=source.get("canonical_url", ""),
        domain=source.get("domain", ""),
        source_date=source.get("source_date", ""),
        trust_level=source.get("trust_level", "unknown"),
        summary=summary,
        entities=entities,
        claims=claims,
        created_at=now,
        updated_at=now,
    )

    try:
        llm_resp = await llm.complete(
            system_prompt="",
            user_message=prompt,
            tier=tier,  # type: ignore
            max_tokens=1200,
            response_format="text",
        )
        page_content = llm_resp.text.strip()
    except LLMError as exc:
        log.error("compile_source_summary_llm_failed", source_id=source_id, error=str(exc))
        # Fallback: generate a minimal page without LLM
        page_content = _minimal_source_summary_page(
            page_id, project_id, source_id, source, summary, entities, claims, now
        )

    # Write atomically
    try:
        existing_rev = snapshot(wiki_path) if wiki_path.exists() else None
        write_atomic(wiki_path, page_content, expected_revision=existing_rev, tmp_dir=vault.tmp_dir)
    except ConflictError as exc:
        log.warning("compile_source_summary_conflict", path=str(wiki_path), error=str(exc))
        return None

    body_sha256 = hashlib.sha256(page_content.encode()).hexdigest()

    # Upsert page record
    if existing_page_row:
        await db.execute(
            """
            UPDATE pages SET body_sha256=?, status='active',
            updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?
            """,
            (body_sha256, existing_page_row["id"]),
        )
        page_id = existing_page_row["id"]
    else:
        await db.execute(
            """
            INSERT INTO pages(id, project_id, page_type, title, slug, file_path,
              frontmatter_json, body_sha256)
            VALUES (?,?,?,?,?,?,?,?)
            """,
            (
                page_id, project_id, "source_summary", title, slug, str(wiki_path),
                json.dumps({"source_id": source_id}), body_sha256,
            ),
        )

    # Record relation: page derived_from source
    rel_id = f"rel_{ULID()}"
    await db.execute(
        """
        INSERT OR IGNORE INTO relations(id, project_id, from_kind, from_id, relation_type, to_kind, to_id)
        VALUES (?,?,?,?,?,?,?)
        """,
        (rel_id, project_id, "page", page_id, "derived_from", "source", source_id),
    )

    # Update source status
    await db.execute(
        "UPDATE sources SET status='compiled', updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
        (source_id,),
    )

    await db.commit()

    # Index in content_units for FTS
    await _index_page_content(db, project_id, page_id, title, page_content, source_id=source_id)

    log.info("source_summary_compiled", source_id=source_id, page_id=page_id)
    return page_id


def _minimal_source_summary_page(
    page_id: str,
    project_id: str,
    source_id: str,
    source: dict,
    summary: str,
    entities: list,
    claims: list,
    now: str,
) -> str:
    """Generate a minimal source summary page without LLM."""
    title = source.get("title") or f"Source {source_id[:12]}"
    url = source.get("canonical_url", "")
    entity_lines = "\n".join(f"- **{e['name']}** ({e.get('entity_type', 'concept')})" for e in entities)
    claim_lines = "\n".join(f"- {c['text']}" for c in claims[:5])

    return f"""---
id: "{page_id}"
project_id: "{project_id}"
page_type: "source_summary"
title: "{title}"
source_id: "{source_id}"
source_type: "{source.get('source_type', 'unknown')}"
source_url: "{url}"
status: "active"
created_at: "{now}"
updated_at: "{now}"
---

## Abstract

{summary}

## Key Concepts

{entity_lines or "No entities extracted."}

## Key Claims

{claim_lines or "No claims extracted."}

## Source Details

- Type: {source.get('source_type', 'unknown')}
- URL: {url or 'N/A'}
- Trust level: {source.get('trust_level', 'unknown')}
"""


async def compile_concept_page(
    entity_id: str,
    project_id: str,
    db: Any,
    vault: Any,
    llm: LLMProvider,
    tier: str = "balanced",
) -> str | None:
    """
    Compile or update a concept page for an entity.

    Returns the page_id, or None if skipped/failed.
    """
    entity = await db.fetchone(
        "SELECT * FROM entities WHERE id=? AND project_id=?",
        (entity_id, project_id),
    )
    if not entity:
        return None

    entity = dict(entity)
    entity_name = entity["display_name"]

    # Find supporting sources via mentions relation and direct creation
    source_ids_rows = await db.fetchall(
        """
        SELECT DISTINCT s.id as source_id, s.title, s.canonical_url,
               COALESCE(json_extract(s.metadata_json, '$.summary'), '') as summary
        FROM sources s
        WHERE s.project_id=? AND s.deleted_at IS NULL
          AND (
            s.id = ? OR
            s.id IN (
              SELECT evidence_source_id FROM relations
              WHERE project_id=? AND to_kind='entity' AND to_id=? AND from_kind='source'
            )
          )
        ORDER BY s.created_at DESC LIMIT ?
        """,
        (project_id, entity.get("created_from_source_id", ""), project_id, entity_id, _MAX_SOURCES_PER_CONCEPT),
    )

    sources = []
    source_ids = []
    for row in source_ids_rows:
        sid = row["source_id"]
        source_ids.append(sid)
        claims_rows = await db.fetchall(
            "SELECT claim_text as text, claim_kind, confidence FROM claims WHERE project_id=? AND created_from_source_id=? ORDER BY confidence DESC LIMIT 5",
            (project_id, sid),
        )
        sources.append({
            "id": sid,
            "title": row["title"] or sid,
            "summary": row["summary"],
            "claims": [dict(r) for r in claims_rows],
        })

    if not sources and not entity.get("description"):
        log.debug("concept_compile_skipped_no_sources", entity_id=entity_id)
        return None

    # Find related entities (1-hop)
    related_rows = await db.fetchall(
        """
        SELECT r.from_id, r.to_id, r.relation_type,
               e1.display_name as from_name, e2.display_name as to_name
        FROM relations r
        JOIN entities e1 ON e1.id = r.from_id
        JOIN entities e2 ON e2.id = r.to_id
        WHERE r.project_id=? AND (r.from_id=? OR r.to_id=?)
          AND r.from_kind='entity' AND r.to_kind='entity'
        LIMIT 10
        """,
        (project_id, entity_id, entity_id),
    )
    related_entities = [dict(r) for r in related_rows]
    related_entity_ids = list({r["from_id"] for r in related_entities} | {r["to_id"] for r in related_entities} - {entity_id})

    slug = _slugify(entity_name)
    wiki_path = vault.wiki_path("concept", slug)
    page_id = f"pg_{ULID()}"
    now = _now_iso()

    aliases = json.loads(entity.get("aliases_json") or "[]")

    # Check for existing page
    existing_page_row = await db.fetchone(
        "SELECT id, file_path, body_sha256 FROM pages WHERE project_id=? AND page_type='concept' AND slug=?",
        (project_id, slug),
    )
    existing_content = wiki_path.read_text(encoding="utf-8") if wiki_path.exists() else None

    template = _jinja.get_template("compile_concept_page_v1.md")
    prompt = template.render(
        entity_name=entity_name,
        entity_type=entity["entity_type"],
        aliases=aliases,
        sources=sources,
        related_entities=related_entities,
        existing_page=existing_content,
        page_id=page_id,
        project_id=project_id,
        source_ids=source_ids,
        related_entity_ids=related_entity_ids,
        created_at=now,
        updated_at=now,
    )

    try:
        llm_resp = await llm.complete(
            system_prompt="",
            user_message=prompt,
            tier=tier,  # type: ignore
            max_tokens=1500,
            response_format="text",
        )
        page_content = llm_resp.text.strip()
    except LLMError as exc:
        log.error("compile_concept_llm_failed", entity_id=entity_id, error=str(exc))
        return None

    # Write atomically
    try:
        existing_rev = snapshot(wiki_path) if wiki_path.exists() else None
        write_atomic(wiki_path, page_content, expected_revision=existing_rev, tmp_dir=vault.tmp_dir)
    except ConflictError as exc:
        log.warning("compile_concept_conflict", path=str(wiki_path), error=str(exc))
        return None

    body_sha256 = hashlib.sha256(page_content.encode()).hexdigest()

    if existing_page_row:
        await db.execute(
            "UPDATE pages SET body_sha256=?, status='active', updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
            (body_sha256, existing_page_row["id"]),
        )
        page_id = existing_page_row["id"]
    else:
        await db.execute(
            """
            INSERT INTO pages(id, project_id, page_type, title, slug, file_path, frontmatter_json, body_sha256)
            VALUES (?,?,?,?,?,?,?,?)
            """,
            (
                page_id, project_id, "concept", entity_name, slug, str(wiki_path),
                json.dumps({"entity_id": entity_id, "source_ids": source_ids}),
                body_sha256,
            ),
        )

    # Record relation: page about entity
    rel_id = f"rel_{ULID()}"
    await db.execute(
        "INSERT OR IGNORE INTO relations(id, project_id, from_kind, from_id, relation_type, to_kind, to_id) VALUES (?,?,?,?,?,?,?)",
        (rel_id, project_id, "page", page_id, "about", "entity", entity_id),
    )

    await db.commit()

    # Index content
    await _index_page_content(db, project_id, page_id, entity_name, page_content)

    log.info("concept_page_compiled", entity_id=entity_id, page_id=page_id)
    return page_id


async def _index_page_content(
    db: Any,
    project_id: str,
    page_id: str,
    title: str,
    content: str,
    source_id: str | None = None,
) -> None:
    """Add or update a content_unit and FTS entry for a page."""
    # Remove existing units for this page
    await db.execute(
        "DELETE FROM content_units WHERE project_id=? AND parent_kind='page' AND parent_id=?",
        (project_id, page_id),
    )

    unit_id = f"cu_{ULID()}"
    token_count = len(content.split())

    await db.execute(
        """
        INSERT INTO content_units(id, project_id, unit_type, parent_kind, parent_id,
          ordinal, title, body, token_count, source_id, page_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """,
        (unit_id, project_id, "page_body", "page", page_id, 0, title, content, token_count, source_id, page_id),
    )

    # Update FTS
    await db.execute(
        "INSERT INTO content_units_fts(rowid, title, body, project_id) VALUES (last_insert_rowid(), ?, ?, ?)",
        (title, content, project_id),
    )

    await db.commit()


async def build_indexes(
    project_id: str,
    db: Any,
    vault: Any,
) -> None:
    """Build/rebuild the wiki index pages (topic indexes, concept list)."""
    # Concept index
    concepts = await db.fetchall(
        "SELECT title, slug FROM pages WHERE project_id=? AND page_type='concept' AND status='active' ORDER BY title",
        (project_id,),
    )
    source_pages = await db.fetchall(
        "SELECT title, slug FROM pages WHERE project_id=? AND page_type='source_summary' AND status='active' ORDER BY title",
        (project_id,),
    )

    concept_lines = "\n".join(f"- [[{r['title']}]]" for r in concepts)
    source_lines = "\n".join(f"- [[{r['title']}]]" for r in source_pages)
    now = _now_iso()

    index_content = f"""---
page_type: "index"
title: "Project Index"
project_id: "{project_id}"
updated_at: "{now}"
---

# Project Index

## Concepts ({len(concepts)})

{concept_lines or "_No concept pages compiled yet._"}

## Sources ({len(source_pages)})

{source_lines or "_No sources compiled yet._"}
"""

    idx_path = vault.wiki / "indexes" / "index.md"
    idx_path.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(idx_path, index_content, tmp_dir=vault.tmp_dir)
    log.info("index_built", project_id=project_id)


async def handle_compile_project(ctx: JobContext) -> dict[str, Any]:
    """
    Job handler: compile all uncompiled sources and update concept pages.

    Payload:
      scope: 'incremental' | 'full'
    """
    scope = ctx.payload.get("scope", "incremental")
    project = await ctx.app_ctx.project_manager.get_project(ctx.project_id)
    db = project.db
    vault = project.vault
    llm = ctx.app_ctx.llm
    tier = project.config.get("default_model_tier", "balanced")

    await ctx.log_event("info", "step_started", "Starting compilation")

    # Step 1: Compile source summaries for normalized sources
    if scope == "incremental":
        sources = await db.fetchall(
            "SELECT id FROM sources WHERE project_id=? AND status='normalized' AND deleted_at IS NULL",
            (ctx.project_id,),
        )
    else:
        sources = await db.fetchall(
            "SELECT id FROM sources WHERE project_id=? AND status IN ('normalized','compiled') AND deleted_at IS NULL",
            (ctx.project_id,),
        )

    compiled_sources = 0
    for row in sources:
        if ctx.cancelled:
            break
        sid = row["id"]
        try:
            page_id = await compile_source_summary(sid, ctx.project_id, db, vault, llm, tier)
            if page_id:
                compiled_sources += 1
        except Exception as exc:
            log.error("compile_source_summary_error", source_id=sid, error=str(exc))

    await ctx.log_event("info", "log", f"Compiled {compiled_sources} source summaries")

    # Step 2: Compile concept pages for entities with enough support
    entities = await db.fetchall(
        "SELECT id FROM entities WHERE project_id=? ORDER BY confidence DESC",
        (ctx.project_id,),
    )

    compiled_concepts = 0
    for row in entities:
        if ctx.cancelled:
            break
        eid = row["id"]
        try:
            page_id = await compile_concept_page(eid, ctx.project_id, db, vault, llm, tier)
            if page_id:
                compiled_concepts += 1
        except Exception as exc:
            log.error("compile_concept_error", entity_id=eid, error=str(exc))

    await ctx.log_event("info", "log", f"Compiled {compiled_concepts} concept pages")

    # Step 3: Rebuild indexes
    await build_indexes(ctx.project_id, db, vault)

    await ctx.log_event("info", "step_finished", "Compilation complete")

    return {
        "compiled_sources": compiled_sources,
        "compiled_concepts": compiled_concepts,
        "scope": scope,
    }
