"""
Query engine.

Implements the full query lifecycle:
  user request → intent classification → query plan → evidence retrieval
  → evidence ranking → synthesis → artifact writing → provenance attachment

Architecture: §17 (complete section)
"""
from __future__ import annotations

import hashlib
import json
import pathlib
from datetime import datetime, timezone
from typing import Any

import structlog
from jinja2 import Environment, FileSystemLoader
from ulid import ULID

from knowler_engine.jobs.types import JobContext
from knowler_engine.llm.provider import LLMError, LLMProvider, parse_llm_json
from knowler_engine.search.fts import exact_search, relation_expand, search_project
from knowler_engine.storage.atomic import ConflictError, snapshot, write_atomic

log = structlog.get_logger(__name__)

_PROMPTS_DIR = pathlib.Path(__file__).parent.parent.parent / "prompts"
_jinja = Environment(loader=FileSystemLoader(str(_PROMPTS_DIR)), autoescape=False)

# Supported task types (§17.4)
TASK_TYPES = {
    "answer", "comparison", "study_guide", "reading_plan", "report",
    "slides", "checklist", "open_questions", "gap_analysis", "maintenance_report",
}

# Default evidence budget (§17.11)
_MAX_WIKI_PAGES = 8
_MAX_SOURCE_SUMMARIES = 5
_MAX_CLAIMS = 15


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _slugify(text: str) -> str:
    import re
    s = text.lower().strip()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_]+", "-", s)
    return s.strip("-")[:80]


async def classify_intent(
    prompt: str,
    task_type_hint: str,
    llm: LLMProvider,
) -> dict[str, Any]:
    """
    Stage 1: Classify the user's intent and produce a query plan.

    Non-LLM first: if task_type is explicit and not 'auto', use it directly.
    LLM: only for 'auto' or ambiguous requests.

    Returns a plan dict matching the query planner prompt contract (§42.5).
    """
    if task_type_hint != "auto" and task_type_hint in TASK_TYPES:
        # Deterministic: extract search terms from prompt
        words = [w.strip(".,?!") for w in prompt.split() if len(w) > 3]
        return {
            "task_type": task_type_hint,
            "output_format": "markdown_report",
            "entities": [],
            "need_raw_sources": False,
            "need_wiki_pages": True,
            "need_claims": True,
            "retrieval_strategy": {
                "search_terms": words[:5],
                "relation_hops": 1,
                "preferred_unit_types": ["comparison", "page_body", "source_summary", "claim"],
                "per_entity_min_sources": 2,
            },
            "synthesis_plan": {"sections": []},
        }

    # LLM-assisted planning for 'auto' task type
    plan_system = """You are a query planner for Knowler knowledge system.
Classify the user's request and produce a retrieval plan as JSON.
Output only valid JSON matching this schema exactly."""

    plan_user = f"""User request: "{prompt}"

Available task types: {', '.join(sorted(TASK_TYPES))}

Return JSON:
{{
  "task_type": "one of the task types above",
  "output_format": "markdown_report",
  "entities": ["entity name 1", "entity name 2"],
  "need_raw_sources": false,
  "need_wiki_pages": true,
  "need_claims": true,
  "retrieval_strategy": {{
    "search_terms": ["term1", "term2"],
    "relation_hops": 1,
    "preferred_unit_types": ["comparison", "page_body", "source_summary", "claim"],
    "per_entity_min_sources": 2
  }},
  "synthesis_plan": {{
    "sections": []
  }}
}}"""

    try:
        resp = await llm.complete(plan_system, plan_user, tier="fast", max_tokens=500, response_format="json")
        plan = parse_llm_json(resp.text)
        # Validate
        if plan.get("task_type") not in TASK_TYPES:
            plan["task_type"] = "report"
        plan.setdefault("output_format", "markdown_report")
        plan.setdefault("entities", [])
        plan.setdefault("retrieval_strategy", {"search_terms": []})
        return plan
    except Exception as exc:
        log.warning("query_plan_llm_failed", error=str(exc))
        # Fallback conservative plan
        words = [w.strip(".,?!") for w in prompt.split() if len(w) > 3]
        return {
            "task_type": "answer",
            "output_format": "markdown_report",
            "entities": [],
            "need_wiki_pages": True,
            "need_claims": True,
            "retrieval_strategy": {"search_terms": words[:5], "relation_hops": 1},
            "synthesis_plan": {"sections": []},
        }


async def gather_evidence(
    db: Any,
    project_id: str,
    plan: dict[str, Any],
) -> dict[str, Any]:
    """
    Stage 2 + 3: Retrieve and rank evidence.

    Returns a structured evidence package.
    Non-LLM by design (§17.8).
    """
    evidence: dict[str, Any] = {
        "wiki_pages": [],
        "source_summaries": [],
        "claims": [],
        "source_ids": set(),
        "page_ids": set(),
    }

    search_terms = plan.get("retrieval_strategy", {}).get("search_terms", [])
    relation_hops = plan.get("retrieval_strategy", {}).get("relation_hops", 1)

    # Layer 1: Exact title/entity matching
    for term in search_terms[:3]:
        exact_results = await exact_search(db, project_id, term, limit=5)
        for r in exact_results:
            if r["kind"] == "page":
                evidence["page_ids"].add(r["id"])
            elif r["kind"] == "entity" and relation_hops > 0:
                expanded = await relation_expand(db, project_id, [r["id"]], hops=relation_hops)
                for rel_ent in expanded[:5]:
                    # Find pages about this related entity
                    pages = await db.fetchall(
                        """
                        SELECT p.id FROM pages p
                        JOIN relations r ON r.from_id = p.id AND r.to_id = ?
                        WHERE r.project_id=? AND r.from_kind='page' AND r.relation_type='about'
                        LIMIT 3
                        """,
                        (rel_ent["entity_id"], project_id),
                    )
                    for p in pages:
                        evidence["page_ids"].add(p["id"])

    # Layer 2: FTS over content_units
    all_terms = " ".join(search_terms[:5])
    if all_terms.strip():
        fts_results = await search_project(
            db, project_id, all_terms,
            limit=20,
            unit_types=plan.get("retrieval_strategy", {}).get("preferred_unit_types"),
        )
        for r in fts_results[:15]:
            if r["page_id"]:
                evidence["page_ids"].add(r["page_id"])
            if r["source_id"]:
                evidence["source_ids"].add(r["source_id"])

    # Load wiki pages
    for page_id in list(evidence["page_ids"])[:_MAX_WIKI_PAGES]:
        row = await db.fetchone(
            "SELECT id, page_type, title, file_path, status FROM pages WHERE id=? AND status='active'",
            (page_id,),
        )
        if not row:
            continue
        page_path = pathlib.Path(row["file_path"])
        if page_path.exists():
            body = page_path.read_text(encoding="utf-8", errors="replace")
            evidence["wiki_pages"].append({
                "id": page_id,
                "page_type": row["page_type"],
                "title": row["title"],
                "body": body,
            })

    # Load source summaries
    for sid in list(evidence["source_ids"])[:_MAX_SOURCE_SUMMARIES]:
        row = await db.fetchone(
            """
            SELECT id, title, canonical_url,
                   json_extract(metadata_json, '$.summary') as summary
            FROM sources WHERE id=? AND deleted_at IS NULL
            """,
            (sid,),
        )
        if row and row["summary"]:
            evidence["source_summaries"].append({
                "source_id": row["id"],
                "title": row["title"],
                "summary": row["summary"][:1000],
            })

    # Load claims
    if plan.get("need_claims", True) and search_terms:
        claim_rows = await db.fetchall(
            """
            SELECT claim_text as text, claim_kind, confidence
            FROM claims WHERE project_id=? AND status='active'
            ORDER BY confidence DESC LIMIT ?
            """,
            (project_id, _MAX_CLAIMS),
        )
        evidence["claims"] = [dict(r) for r in claim_rows]

    evidence["source_ids"] = list(evidence["source_ids"])
    evidence["page_ids"] = list(evidence["page_ids"])

    log.info(
        "evidence_gathered",
        project_id=project_id,
        pages=len(evidence["wiki_pages"]),
        sources=len(evidence["source_summaries"]),
        claims=len(evidence["claims"]),
    )
    return evidence


async def synthesize_artifact(
    prompt: str,
    plan: dict[str, Any],
    evidence: dict[str, Any],
    artifact_id: str,
    query_run_id: str,
    project_id: str,
    llm: LLMProvider,
    tier: str,
) -> str:
    """
    Stage 4: Generate the artifact using the LLM synthesizer.

    Returns the markdown content of the artifact.
    """
    task_type = plan.get("task_type", "report")
    output_format = plan.get("output_format", "markdown_report")

    # Build title
    title = prompt[:80].strip()
    if len(prompt) > 80:
        title += "..."

    source_ids = evidence.get("source_ids", [])
    page_ids = evidence.get("page_ids", [])
    now = _now_iso()

    template = _jinja.get_template("synthesize_report_v1.md")
    synthesis_prompt = template.render(
        prompt=prompt,
        task_type=task_type,
        output_format=output_format,
        wiki_pages=evidence.get("wiki_pages", []),
        source_summaries=evidence.get("source_summaries", []),
        claims=evidence.get("claims", []),
        artifact_id=artifact_id,
        project_id=project_id,
        title=title,
        query_run_id=query_run_id,
        source_ids=source_ids,
        page_ids=page_ids,
        created_at=now,
    )

    resp = await llm.complete(
        system_prompt="",
        user_message=synthesis_prompt,
        tier=tier,  # type: ignore
        max_tokens=2000,
        response_format="text",
    )
    return resp.text.strip()


async def write_artifact(
    content: str,
    artifact_id: str,
    query_run_id: str,
    project_id: str,
    task_type: str,
    title: str,
    db: Any,
    vault: Any,
    source_ids: list[str],
    page_ids: list[str],
) -> dict[str, Any]:
    """
    Stage 5: Write artifact to disk and record in DB.

    Returns artifact metadata dict.
    """
    slug = _slugify(title)
    ext = ".md"
    filename = f"{artifact_id}_{slug}{ext}"
    artifact_path = vault.output_path(task_type, filename)
    artifact_path.parent.mkdir(parents=True, exist_ok=True)

    # Append provenance footer if not already present
    if "## Sources Used" not in content and "## Sources used" not in content:
        source_lines = "\n".join(f"- {sid}" for sid in source_ids[:10])
        page_lines = "\n".join(f"- {pid}" for pid in page_ids[:10])
        now = _now_iso()
        provenance = f"""

---

## Sources Used

{source_lines or "_No sources_"}

## Pages Used

{page_lines or "_No pages_"}

---
*Generated by Knowler at {now}*
"""
        content = content + provenance

    write_atomic(artifact_path, content, tmp_dir=vault.tmp_dir)
    sha256 = hashlib.sha256(content.encode()).hexdigest()

    await db.execute(
        """
        INSERT INTO artifacts(id, project_id, artifact_type, title, file_path, source_query_run_id, metadata_json)
        VALUES (?,?,?,?,?,?,?)
        """,
        (
            artifact_id, project_id, task_type, title, str(artifact_path),
            query_run_id,
            json.dumps({"source_ids": source_ids, "page_ids": page_ids, "sha256": sha256}),
        ),
    )

    # Update query run with artifact id
    await db.execute(
        "UPDATE query_runs SET result_artifact_id=?, status='succeeded', finished_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
        (artifact_id, query_run_id),
    )
    await db.commit()

    # Index artifact for FTS
    unit_id = f"cu_{ULID()}"
    await db.execute(
        """
        INSERT INTO content_units(id, project_id, unit_type, parent_kind, parent_id, ordinal, title, body, artifact_id)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (unit_id, project_id, "artifact_body", "artifact", artifact_id, 0, title, content[:5000], artifact_id),
    )
    await db.execute(
        "INSERT INTO content_units_fts(rowid, title, body, project_id) VALUES (last_insert_rowid(), ?, ?, ?)",
        (title, content[:5000], project_id),
    )
    await db.commit()

    log.info("artifact_written", artifact_id=artifact_id, path=str(artifact_path))

    return {
        "artifact_id": artifact_id,
        "artifact_path": str(artifact_path),
        "title": title,
        "artifact_type": task_type,
    }


async def handle_query(ctx: JobContext) -> dict[str, Any]:
    """
    Job handler for query.run.

    Payload:
      query_run_id: str
      prompt: str
      task_type: str
      output_format: str
      model_tier: str
      file_back: bool
    """
    payload = ctx.payload
    query_run_id = payload.get("query_run_id")
    prompt = payload.get("prompt", "")
    task_type_hint = payload.get("task_type", "auto")
    tier = payload.get("model_tier", "balanced")

    if not prompt:
        raise ValueError("prompt is required")

    project = await ctx.app_ctx.project_manager.get_project(ctx.project_id)
    db = project.db
    vault = project.vault
    llm = ctx.app_ctx.llm

    # Stage 1: Intent classification
    await ctx.log_event("info", "step_started", "Planning query")
    if hasattr(ctx.app_ctx, "router"):
        await ctx.app_ctx.router.emit("query.phase_changed", {"query_run_id": query_run_id, "phase": "planning"})

    plan = await classify_intent(prompt, task_type_hint, llm)

    # Update query run with plan
    if query_run_id:
        await db.execute(
            "UPDATE query_runs SET plan_json=?, status='gathering' WHERE id=?",
            (json.dumps(plan), query_run_id),
        )
        await db.commit()

    # Stage 2+3: Evidence gathering
    await ctx.log_event("info", "step_started", "Gathering evidence")
    if hasattr(ctx.app_ctx, "router"):
        await ctx.app_ctx.router.emit("query.phase_changed", {"query_run_id": query_run_id, "phase": "retrieving"})

    evidence = await gather_evidence(db, ctx.project_id, plan)

    if not evidence["wiki_pages"] and not evidence["source_summaries"]:
        await ctx.log_event("warn", "log", "Insufficient evidence found for query")
        if query_run_id:
            await db.execute(
                "UPDATE query_runs SET status='failed' WHERE id=?",
                (query_run_id,),
            )
            await db.commit()
        return {"error": "insufficient_evidence", "prompt": prompt}

    # Stage 4: Synthesis
    await ctx.log_event("info", "step_started", "Synthesizing artifact")
    if hasattr(ctx.app_ctx, "router"):
        await ctx.app_ctx.router.emit("query.phase_changed", {"query_run_id": query_run_id, "phase": "synthesizing"})

    artifact_id = f"art_{ULID()}"
    title = prompt[:80].rstrip(".? ")

    try:
        content = await synthesize_artifact(
            prompt=prompt,
            plan=plan,
            evidence=evidence,
            artifact_id=artifact_id,
            query_run_id=query_run_id or "",
            project_id=ctx.project_id,
            llm=llm,
            tier=tier,
        )
    except LLMError as exc:
        log.error("query_synthesis_failed", error=str(exc))
        if query_run_id:
            await db.execute(
                "UPDATE query_runs SET status='failed' WHERE id=?", (query_run_id,)
            )
            await db.commit()
        raise

    # Stage 5: File back
    await ctx.log_event("info", "step_started", "Writing artifact")
    if hasattr(ctx.app_ctx, "router"):
        await ctx.app_ctx.router.emit("query.phase_changed", {"query_run_id": query_run_id, "phase": "writing"})

    artifact_meta = await write_artifact(
        content=content,
        artifact_id=artifact_id,
        query_run_id=query_run_id or "",
        project_id=ctx.project_id,
        task_type=plan["task_type"],
        title=title,
        db=db,
        vault=vault,
        source_ids=evidence.get("source_ids", []),
        page_ids=evidence.get("page_ids", []),
    )

    if hasattr(ctx.app_ctx, "router"):
        await ctx.app_ctx.router.emit("artifact.created", {
            "artifact_id": artifact_id,
            "project_id": ctx.project_id,
            "title": title,
        })

    await ctx.log_event("info", "step_finished", f"Artifact created: {title[:60]}")
    return artifact_meta
